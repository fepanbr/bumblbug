package Bean;

public class BoardBeans {
	private int b_idx;
	private String b_time;
	private String b_content;
	private int b_pj_idx;
	private int b_u_idx;
	
	public int getB_idx() {
		return b_idx;
	}
	public void setB_idx(int b_idx) {
		this.b_idx = b_idx;
	}
	public String getB_time() {
		return b_time;
	}
	public void setB_time(String b_time) {
		this.b_time = b_time;
	}
	public String getB_content() {
		return b_content;
	}
	public void setB_content(String b_content) {
		this.b_content = b_content;
	}
	public int getB_pj_idx() {
		return b_pj_idx;
	}
	public void setB_pj_idx(int b_pj_idx) {
		this.b_pj_idx = b_pj_idx;
	}
	public int getB_u_idx() {
		return b_u_idx;
	}
	public void setB_u_idx(int b_u_idx) {
		this.b_u_idx = b_u_idx;
	}
}
