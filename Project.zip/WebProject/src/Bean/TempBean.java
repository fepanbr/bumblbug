package Bean;

public class TempBean {
	private int tp_idx;
	private String tp_title;
	private String tp_short_title;
	private String tp_img;
	private String tp_summary;
	private String tp_category;
	private String tp_url;
	private String tp_search_tag;
	private String tp_profile_img;
	private String tp_leader_nm;
	private String tp_leader_intro;
	private String tp_leader_loc;
	private String tp_end_dt;
	private String tp_intro_video;
	private int tp_u_idx;
	private String tp_story;
	private String tp_obj_price;
	private String tp_reg_dt;
	private String tp_ac_no;
	private String tp_ah;
	private String tp_bank_nm;
	private String tp_st;
	private String tp_ah_birth;
	public int getTp_idx() {
		return tp_idx;
	}
	public void setTp_idx(int tp_idx) {
		this.tp_idx = tp_idx;
	}
	public String getTp_title() {
		return tp_title;
	}
	public void setTp_title(String tp_title) {
		this.tp_title = tp_title;
	}
	public String getTp_short_title() {
		return tp_short_title;
	}
	public void setTp_short_title(String tp_short_title) {
		this.tp_short_title = tp_short_title;
	}
	public String getTp_img() {
		return tp_img;
	}
	public void setTp_img(String tp_img) {
		this.tp_img = tp_img;
	}
	public String getTp_summary() {
		return tp_summary;
	}
	public void setTp_summary(String tp_summary) {
		this.tp_summary = tp_summary;
	}
	public String getTp_category() {
		return tp_category;
	}
	public void setTp_category(String tp_category) {
		this.tp_category = tp_category;
	}
	public String getTp_url() {
		return tp_url;
	}
	public void setTp_url(String tp_url) {
		this.tp_url = tp_url;
	}
	public String getTp_search_tag() {
		return tp_search_tag;
	}
	public void setTp_search_tag(String tp_search_tag) {
		this.tp_search_tag = tp_search_tag;
	}
	public String getTp_profile_img() {
		return tp_profile_img;
	}
	public void setTp_profile_img(String tp_profile_img) {
		this.tp_profile_img = tp_profile_img;
	}
	public String getTp_leader_nm() {
		return tp_leader_nm;
	}
	public void setTp_leader_nm(String tp_leader_nm) {
		this.tp_leader_nm = tp_leader_nm;
	}
	public String getTp_leader_intro() {
		return tp_leader_intro;
	}
	public void setTp_leader_intro(String tp_leader_intro) {
		this.tp_leader_intro = tp_leader_intro;
	}
	public String getTp_leader_loc() {
		return tp_leader_loc;
	}
	public void setTp_leader_loc(String tp_leader_loc) {
		this.tp_leader_loc = tp_leader_loc;
	}
	public String getTp_end_dt() {
		return tp_end_dt;
	}
	public void setTp_end_dt(String tp_end_dt) {
		this.tp_end_dt = tp_end_dt;
	}
	public String getTp_intro_video() {
		return tp_intro_video;
	}
	public void setTp_intro_video(String tp_intro_video) {
		this.tp_intro_video = tp_intro_video;
	}
	public int getTp_u_idx() {
		return tp_u_idx;
	}
	public void setTp_u_idx(int tp_u_idx) {
		this.tp_u_idx = tp_u_idx;
	}
	public String getTp_story() {
		return tp_story;
	}
	public void setTp_story(String tp_story) {
		this.tp_story = tp_story;
	}
	public String getTp_obj_price() {
		return tp_obj_price;
	}
	public void setTp_obj_price(String tp_obj_price) {
		this.tp_obj_price = tp_obj_price;
	}
	public String getTp_reg_dt() {
		return tp_reg_dt;
	}
	public void setTp_reg_dt(String tp_reg_dt) {
		this.tp_reg_dt = tp_reg_dt;
	}
	public String getTp_ac_no() {
		return tp_ac_no;
	}
	public void setTp_ac_no(String tp_ac_no) {
		this.tp_ac_no = tp_ac_no;
	}
	public String getTp_ah() {
		return tp_ah;
	}
	public void setTp_ah(String tp_ah) {
		this.tp_ah = tp_ah;
	}
	public String getTp_bank_nm() {
		return tp_bank_nm;
	}
	public void setTp_bank_nm(String tp_bank_nm) {
		this.tp_bank_nm = tp_bank_nm;
	}
	public String getTp_st() {
		return tp_st;
	}
	public void setTp_st(String tp_st) {
		this.tp_st = tp_st;
	}
	public String getTp_ah_birth() {
		return tp_ah_birth;
	}
	public void setTp_ah_birth(String tp_ah_birth) {
		this.tp_ah_birth = tp_ah_birth;
	}
	
	

}
