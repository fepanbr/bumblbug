package Bean;

public class PayBean {
	private int pay_idx;
	private String pay_means;
	private int pay_price;
	private int pay_f_idx;
	private String pay_dt;
	private String pay_st;
	public int getPay_idx() {
		return pay_idx;
	}
	public void setPay_idx(int pay_idx) {
		this.pay_idx = pay_idx;
	}
	public String getPay_means() {
		return pay_means;
	}
	public void setPay_means(String pay_means) {
		this.pay_means = pay_means;
	}
	public int getPay_price() {
		return pay_price;
	}
	public void setPay_price(int pay_price) {
		this.pay_price = pay_price;
	}
	public int getPay_f_idx() {
		return pay_f_idx;
	}
	public void setPay_f_idx(int pay_f_idx) {
		this.pay_f_idx = pay_f_idx;
	}
	public String getPay_dt() {
		return pay_dt;
	}
	public void setPay_dt(String pay_dt) {
		this.pay_dt = pay_dt;
	}
	public String getPay_st() {
		return pay_st;
	}
	public void setPay_st(String pay_st) {
		this.pay_st = pay_st;
	}

}
