package Bean;


public class FundBean {
	private int f_idx;
	private String f_dt;
	private String f_deadline;
	private int f_price;
	private int supmem_idx;
	private int f_pj_idx;
	private int f_p_idx;
	private int f_d_idx;
	private ProjectBean projectbean;
	private PresentBean presentbean;
	private PayBean paybean;
	private DelBean delbean;
	
	
	public DelBean getDelbean() {
		return delbean;
	}
	public void setDelbean(DelBean delbean) {
		this.delbean = delbean;
	}
	public PayBean getPaybean() {
		return paybean;
	}
	public void setPaybean(PayBean paybean) {
		this.paybean = paybean;
	}
	public PresentBean getPresentbean() {
		return presentbean;
	}
	public void setPresentbean(PresentBean presentbean) {
		this.presentbean = presentbean;
	}
	public ProjectBean getProjectbean() {
		return projectbean;
	}
	public void setProjectbean(ProjectBean projectbean) {
		this.projectbean = projectbean;
	}
	public int getF_idx() {
		return f_idx;
	}
	public void setF_idx(int f_idx) {
		this.f_idx = f_idx;
	}
	public String getF_dt() {
		return f_dt;
	}
	public void setF_dt(String f_dt) {
		this.f_dt = f_dt;
	}
	public String getF_deadline() {
		return f_deadline;
	}
	public void setF_deadline(String f_deadline) {
		this.f_deadline = f_deadline;
	}
	public int getF_price() {
		return f_price;
	}
	public void setF_price(int f_price) {
		this.f_price = f_price;
	}
	public int getSupmem_idx() {
		return supmem_idx;
	}
	public void setSupmem_idx(int supmem_idx) {
		this.supmem_idx = supmem_idx;
	}
	public int getF_pj_idx() {
		return f_pj_idx;
	}
	public void setF_pj_idx(int f_pj_idx) {
		this.f_pj_idx = f_pj_idx;
	}
	public int getF_p_idx() {
		return f_p_idx;
	}
	public void setF_p_idx(int f_p_idx) {
		this.f_p_idx = f_p_idx;
	}
	public int getF_d_idx() {
		return f_d_idx;
	}
	public void setF_d_idx(int f_d_idx) {
		this.f_d_idx = f_d_idx;
	}
	
	
	
	
	
	

}
