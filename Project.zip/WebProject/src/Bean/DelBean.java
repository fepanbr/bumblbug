package Bean;

public class DelBean {
	private int d_idx;
	private int d_u_idx;
	private String d_ph;
	private String d_zipcode;
	private String d_addr;
	private String d_detail_addr;
	public int getD_idx() {
		return d_idx;
	}
	public void setD_idx(int d_idx) {
		this.d_idx = d_idx;
	}
	public int getD_u_idx() {
		return d_u_idx;
	}
	public void setD_u_idx(int d_u_idx) {
		this.d_u_idx = d_u_idx;
	}
	public String getD_ph() {
		return d_ph;
	}
	public void setD_ph(String d_ph) {
		this.d_ph = d_ph;
	}
	public String getD_zipcode() {
		return d_zipcode;
	}
	public void setD_zipcode(String d_zipcode) {
		this.d_zipcode = d_zipcode;
	}
	public String getD_addr() {
		return d_addr;
	}
	public void setD_addr(String d_addr) {
		this.d_addr = d_addr;
	}
	public String getD_detail_addr() {
		return d_detail_addr;
	}
	public void setD_detail_addr(String d_detail_addr) {
		this.d_detail_addr = d_detail_addr;
	}

}
