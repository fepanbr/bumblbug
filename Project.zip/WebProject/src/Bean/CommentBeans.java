package Bean;

public class CommentBeans {
	private int c_idx;
	private String c_content;
	private int c_u_idx;
	private int c_b_idx;
	private String c_dt;
	public int getC_idx() {
		return c_idx;
	}
	public void setC_idx(int c_idx) {
		this.c_idx = c_idx;
	}
	public String getC_content() {
		return c_content;
	}
	public void setC_content(String c_content) {
		this.c_content = c_content;
	}
	public int getC_u_idx() {
		return c_u_idx;
	}
	public void setC_u_idx(int c_u_idx) {
		this.c_u_idx = c_u_idx;
	}
	public int getC_b_idx() {
		return c_b_idx;
	}
	public void setC_b_idx(int c_b_idx) {
		this.c_b_idx = c_b_idx;
	}
	public String getC_dt() {
		return c_dt;
	}
	public void setC_dt(String c_dt) {
		this.c_dt = c_dt;
	}
	
	
	
}
