package Bean;

public class PresentBean {
	
	private String p_nm;
	private int p_idx;
	private int min_price;
	private String p_explain;
	private String due_dt;
	private int supmem_cnt;
	private int limit_amount;
	private int pj_p_idx;
	
	
	public String getP_nm() {
		return p_nm;
	}
	public void setP_nm(String p_nm) {
		this.p_nm = p_nm;
	}
	
	public int getP_idx() {
		return p_idx;
	}
	public void setP_idx(int p_idx) {
		this.p_idx = p_idx;
	}
	public int getMin_price() {
		return min_price;
	}
	public void setMin_price(int min_price) {
		this.min_price = min_price;
	}
	public String getP_explain() {
		return p_explain;
	}
	public void setP_explain(String p_explain) {
		this.p_explain = p_explain;
	}
	public String getDue_dt() {
		return due_dt;
	}
	public void setDue_dt(String due_dt) {
		this.due_dt = due_dt;
	}
	public int getSupmem_cnt() {
		return supmem_cnt;
	}
	public void setSupmem_cnt(int supmem_cnt) {
		this.supmem_cnt = supmem_cnt;
	}
	public int getLimit_amount() {
		return limit_amount;
	}
	public void setLimit_amount(int limit_amount) {
		this.limit_amount = limit_amount;
	}
	
	public int getPj_p_idx() {
		return pj_p_idx;
	}
	public void setPj_p_idx(int pj_p_idx) {
		this.pj_p_idx = pj_p_idx;
	}

}
