package Bean;

public class PayInfoBean {
	private int pay_info_idx;
	private int pay_u_idx;
	private String pay_info_means;
	private String card_no;
	private String card_valid;
	private String owner_birth;
	private String card_pwd;
	private String owner_ph;
	public int getPay_info_idx() {
		return pay_info_idx;
	}
	public void setPay_info_idx(int pay_info_idx) {
		this.pay_info_idx = pay_info_idx;
	}
	public int getPay_u_idx() {
		return pay_u_idx;
	}
	public void setPay_u_idx(int pay_u_idx) {
		this.pay_u_idx = pay_u_idx;
	}
	public String getPay_info_means() {
		return pay_info_means;
	}
	public void setPay_info_means(String pay_info_means) {
		this.pay_info_means = pay_info_means;
	}
	public String getCard_no() {
		return card_no;
	}
	public void setCard_no(String card_no) {
		this.card_no = card_no;
	}
	public String getCard_valid() {
		return card_valid;
	}
	public void setCard_valid(String card_valid) {
		this.card_valid = card_valid;
	}
	public String getOwner_birth() {
		return owner_birth;
	}
	public void setOwner_birth(String owner_birth) {
		this.owner_birth = owner_birth;
	}
	public String getCard_pwd() {
		return card_pwd;
	}
	public void setCard_pwd(String card_pwd) {
		this.card_pwd = card_pwd;
	}
	public String getOwner_ph() {
		return owner_ph;
	}
	public void setOwner_ph(String owner_ph) {
		this.owner_ph = owner_ph;
	}
	
	

}
